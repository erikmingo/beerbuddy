version = '1.1.1'
release = False

# for csc downstream releases
downstream_version = '4'
version = '%s.%s' % (version, downstream_version)
