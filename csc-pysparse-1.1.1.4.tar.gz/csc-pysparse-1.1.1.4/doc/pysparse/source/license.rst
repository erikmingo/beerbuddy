.. License under which Pysparse is distributed
.. _license-page:

=======
License
=======

.. literalinclude:: ../../../LICENSE
